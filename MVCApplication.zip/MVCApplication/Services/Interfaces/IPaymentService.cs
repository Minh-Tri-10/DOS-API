﻿namespace MVCApplication.Services.Interfaces
{
    public interface Interface
    {
    }
}
